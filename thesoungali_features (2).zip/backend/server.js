// Simple Express backend (in-memory data)
const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const app = express();
app.use(cors());
app.use(express.json());

const users = {}; // userId -> {id, name, email}
const posts = {}; // postId -> {id, authorId, content, likes: Set, shares: number, comments: [{id, userId, text}]}

// create a demo post
const demoPostId = uuidv4();
posts[demoPostId] = { id: demoPostId, authorId: 'system', content: 'Bienvenue sur thesoungali.com — post démo', likes: new Set(), shares: 0, comments: [] };

// Signup
app.post('/api/signup', (req, res) => {
  const { name, email } = req.body;
  if(!name || !email) return res.status(400).json({error:'name and email required'});
  const id = uuidv4();
  users[id] = {id, name, email};
  res.json({user: users[id]});
});

// List posts
app.get('/api/posts', (req, res) => {
  const arr = Object.values(posts).map(p=>({ 
    id: p.id, authorId: p.authorId, content: p.content, likes: Array.from(p.likes), shares: p.shares, comments: p.comments
  }));
  res.json({posts: arr});
});

// Like/unlike a post
app.post('/api/posts/:id/like', (req, res) => {
  const pid = req.params.id;
  const { userId } = req.body;
  const p = posts[pid];
  if(!p) return res.status(404).json({error:'post not found'});
  if(p.likes.has(userId)) p.likes.delete(userId);
  else p.likes.add(userId);
  res.json({likes: Array.from(p.likes)});
});

// Share a post (increments counter and returns new share count)
app.post('/api/posts/:id/share', (req, res) => {
  const pid = req.params.id;
  const p = posts[pid];
  if(!p) return res.status(404).json({error:'post not found'});
  p.shares += 1;
  res.json({shares: p.shares});
});

// Comment
app.post('/api/posts/:id/comment', (req, res) => {
  const pid = req.params.id;
  const { userId, text } = req.body;
  if(!text) return res.status(400).json({error:'text required'});
  const p = posts[pid];
  if(!p) return res.status(404).json({error:'post not found'});
  const cid = uuidv4();
  const comment = { id: cid, userId, text };
  p.comments.push(comment);
  res.json({comment});
});

// Request certification (simple endpoint)
const certifications = [];
app.post('/api/certify', (req, res) => {
  const { userId, platform, proof } = req.body;
  if(!userId || !platform || !proof) return res.status(400).json({error:'userId, platform, proof required'});
  const reqObj = { id: uuidv4(), userId, platform, proof, status: 'pending', createdAt: new Date().toISOString() };
  certifications.push(reqObj);
  res.json({request: reqObj});
});

// Start server
const port = process.env.PORT || 3000;
app.listen(port, () => console.log('Backend listening on port', port));

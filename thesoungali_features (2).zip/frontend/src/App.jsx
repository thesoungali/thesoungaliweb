import React, {useEffect, useState} from 'react';
import axios from 'axios';

function Signup({onSignup}){
  const [name,setName]=useState(''); const [email,setEmail]=useState('');
  const submit = async ()=>{
    const res = await axios.post('/api/signup',{name,email});
    onSignup(res.data.user);
  }
  return (<div className='card'>
    <h3>Inscription</h3>
    <input placeholder='Nom' value={name} onChange={e=>setName(e.target.value)} />
    <input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} style={{marginTop:8}} />
    <div style={{marginTop:8}}><button onClick={submit}>S'inscrire</button></div>
  </div>)
}

function Post({p, me, refresh}){
  const [commentText, setCommentText] = useState('');
  const like = async ()=>{ await axios.post(`/api/posts/${p.id}/like`, {userId: me?.id}); refresh(); }
  const share = async ()=>{ await axios.post(`/api/posts/${p.id}/share`); refresh(); }
  const comment = async ()=>{ if(!commentText) return; await axios.post(`/api/posts/${p.id}/comment`, {userId: me?.id, text: commentText}); setCommentText(''); refresh(); }
  return (<div className='card'>
    <div style={{display:'flex', justifyContent:'space-between'}}><strong>{p.content}</strong><span className='small'>by {p.authorId}</span></div>
    <div style={{marginTop:8}} className='small'>Likes: {p.likes.length} · Shares: {p.shares} · Comments: {p.comments.length}</div>
    <div style={{marginTop:8}}>
      <button onClick={like}>👍</button> <button onClick={share}>↗️</button>
    </div>
    <div style={{marginTop:8}}>
      <input placeholder='Ecrire un commentaire...' value={commentText} onChange={e=>setCommentText(e.target.value)} />
      <div style={{marginTop:6}}><button onClick={comment}>Commenter</button></div>
    </div>
    <div style={{marginTop:8}}>
      {p.comments.map(c=> (<div key={c.id} style={{marginTop:6}} className='small'><b>{c.userId}</b>: {c.text}</div>))}
    </div>
  </div>)
}

function Certify({me}){
  const [platform, setPlatform] = useState('X'); const [proof, setProof] = useState('');
  const submit = async ()=>{
    if(!me) return alert('Connectez-vous d\'abord');
    await axios.post('/api/certify',{userId: me.id, platform, proof});
    alert('Demande envoyée (statut: pending)');
    setProof('');
  }
  return (<div className='card'>
    <h3>Demande de certification</h3>
    <select value={platform} onChange={e=>setPlatform(e.target.value)}>
      <option>X</option><option>Instagram</option><option>TikTok</option>
    </select>
    <textarea placeholder='Preuve (URL, capture...)' value={proof} onChange={e=>setProof(e.target.value)} style={{marginTop:8}}/>
    <div style={{marginTop:8}}><button onClick={submit}>Demander</button></div>
  </div>)
}

export default function App(){
  const [me,setMe] = useState(null);
  const [posts,setPosts] = useState([]);
  const load = async ()=>{ const res = await axios.get('/api/posts'); setPosts(res.data.posts); };
  useEffect(()=>{ load(); },[]);

  return (<div>
    <h1>thesoungali — features demo</h1>
    {!me && <Signup onSignup={(u)=>{setMe(u); alert('Inscrit: '+u.name)}} />}
    {me && <div className='card'><div>Connecté en tant que <b>{me.name}</b></div></div>}

    <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:16}}>
      <div>
        <h2>Posts</h2>
        {posts.map(p=> <Post key={p.id} p={p} me={me} refresh={load} />)}
      </div>
      <aside>
        <Certify me={me} />
        <div className='card'><h3>Partager</h3><div className='small'>Boutons de partage social (exemple)</div></div>
      </aside>
    </div>
  </div>)
}

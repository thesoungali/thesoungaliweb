# Conditions d'utilisation — thesoungali.com

Dernière mise à jour : 2025-08-29

En utilisant ce site (thesoungali.com) et les services associés (inscription, commentaires, likes,
partages, demande de certification), vous acceptez les conditions suivantes :

1. **Acceptation**  
   En accédant au site, vous acceptez ces conditions d’utilisation. Si vous n’êtes pas d’accord,
   veuillez ne pas utiliser le site.

2. **Compte utilisateur**  
   - Vous devez fournir des informations exactes lors de l’inscription.  
   - Vous êtes responsable de la confidentialité de vos identifiants.  
   - Le site se réserve le droit de suspendre tout compte en cas d’utilisation abusive.

3. **Contenu généré par l’utilisateur**  
   - Vous êtes seul responsable du contenu que vous publiez (commentaires, partages, preuves de certification, etc.).  
   - Aucun contenu illégal, diffamatoire, ou portant atteinte aux droits d’autrui n’est autorisé.  
   - L’équipe se réserve le droit de modérer ou supprimer du contenu sans préavis.

4. **Certification**  
   - Les demandes de certification doivent être accompagnées de preuves valides.  
   - Le traitement de la demande ne garantit pas l’obtention de la certification.  
   - Les fausses informations peuvent entraîner un bannissement définitif.

5. **Sécurité et confidentialité**  
   - Les données personnelles sont traitées avec soin, mais vous devez comprendre que
     toute transmission sur Internet comporte des risques.  
   - Le site met en place des mesures de sécurité mais ne peut garantir une sécurité absolue.

6. **Limitations de responsabilité**  
   - Le site est fourni « tel quel » sans garantie.  
   - En aucun cas Soungali Diarra ou son équipe ne pourront être tenus responsables de pertes
     ou dommages résultant de l’utilisation du site.

7. **Modifications**  
   - Les conditions d’utilisation peuvent être modifiées à tout moment.  
   - Les utilisateurs seront informés en cas de changement important.

8. **Droit applicable**  
   - Ces conditions sont régies par le droit applicable au Burkina Faso (ou autre juridiction pertinente).

---

© 2025 Soungali Diarra — Tous droits réservés

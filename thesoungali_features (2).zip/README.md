thesoungali_features — Minimal fullstack example
-----------------------------------------------
This repository contains a simple React frontend (Vite) and an Express backend
demonstrating: signup, comments, likes, shares, and certification request handling.

Notes:
- Data is stored in-memory (not persistent). For production, replace with a database.
- The frontend calls the backend at /api/*. Adjust proxy or CORS for real deployments.

Structure:
- frontend/  : React app (Vite)
- backend/   : Express API server

How to run:
1) Start backend:
   cd backend
   npm install
   node server.js
2) Start frontend (in a separate terminal):
   cd frontend
   npm install
   npm run dev

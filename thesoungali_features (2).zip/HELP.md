# Page d'aide — thesoungali.com

Bienvenue sur l'aide officielle de **thesoungali.com**.  
Cette page vous guide dans l'utilisation du site et de ses fonctionnalités principales.

## 1. Inscription et connexion
- Cliquez sur **S'inscrire** pour créer un compte avec votre email et mot de passe.
- Si vous avez déjà un compte, utilisez **Se connecter**.
- En cas d’oubli de mot de passe, cliquez sur **Mot de passe oublié** pour réinitialiser.

## 2. Commentaires
- Vous pouvez ajouter un commentaire sous un post ou une publication.
- Les commentaires inappropriés peuvent être signalés et supprimés.

## 3. Likes et partages
- Cliquez sur le bouton **Like** pour exprimer votre appréciation.
- Cliquez sur **Partager** pour publier un contenu sur votre profil ou d'autres réseaux sociaux.

## 4. Demande de certification
- Accédez à **Certification** dans votre profil.
- Fournissez les documents ou preuves demandés pour justifier votre identité.
- Une fois validée, une coche de certification apparaîtra à côté de votre nom.

## 5. Paramètres du compte
- Vous pouvez modifier vos informations (nom, mot de passe, photo de profil) dans la section **Paramètres**.
- Activez la **double authentification (2FA)** pour plus de sécurité.

## 6. Sécurité
- Ne partagez pas vos identifiants avec d’autres personnes.
- Signalez immédiatement toute activité suspecte à l’administration du site.

## 7. Support technique
- Si vous rencontrez un problème technique, contactez-nous via :  
  - Email : support@thesoungali.com  
  - Réseaux sociaux : [@thesoungali](https://x.com/thesoungali)

---

© 2025 Soungali Diarra — Tous droits réservés
